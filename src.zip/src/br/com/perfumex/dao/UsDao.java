package br.com.perfumex.dao;

import br.com.perfumesx.modelo.Usuario;

public interface UsDao {

	
	Usuario buscaPorEmail(String email);
	Usuario buscaPorSenha(String senha);
	Usuario existeUsuario(Usuario usuario);
	
	
}
