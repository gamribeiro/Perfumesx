package br.com.perfumex.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import br.com.perfumesx.modelo.Usuario;

@Repository
public class UsuarioDao implements UsDao {

	@PersistenceContext
	EntityManager manager;

	public Usuario buscaPorEmail(String email) {
		
		   
	        
		return manager.find(Usuario.class, email);
	}

	public Usuario buscaPorSenha(String senha) {

		return manager.find(Usuario.class, senha);
	}
	
	public Usuario existeUsuario(Usuario usuario) {
     
		Query query = manager.createQuery("select u from usuarios u where login like :login and senha like :senha");    
        query.setParameter("login", usuario.getLogin());
        query.setParameter("senha", usuario.getSenha());
        Usuario retorno = new Usuario();
        try{
        retorno = (Usuario)query.getSingleResult();
        return retorno;
        }catch(Exception e){
        	throw new RuntimeException(e);       	
        	       	
        	
        }
        
        
		
	}
}
