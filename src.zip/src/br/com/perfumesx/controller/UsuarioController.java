package br.com.perfumesx.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.perfumesx.modelo.Usuario;
import br.com.perfumex.dao.UsDao;

@Transactional
@Controller
public class UsuarioController {

	
	@Autowired	
	UsDao dao;
	
	@RequestMapping("admin")
	public String form(){
		
		return "administracao/login";
	}
	
	@RequestMapping("efetuaLogin")
	public String efetuaLogin(Usuario usuario, HttpSession session){
	
		if(dao.existeUsuario(usuario).getLogin() != null){
			session.setAttribute("usuarioLogado",usuario);
			return "administracao/menu";
			
		}
		
		return "redirect:admin";
	}
}
